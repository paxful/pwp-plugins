<?php
namespace Paxful\Payments\Logger;

class WebhooksLogger extends \Monolog\Logger
{
    //
}
