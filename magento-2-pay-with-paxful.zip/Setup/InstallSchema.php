<?php

namespace Paxful\Payments\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * Installs DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        // Order UUID
        $installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'paxful_track_id',
            [
                'type'     => Table::TYPE_TEXT,
                'length'   => '255',
                'unsigned' => true,
                'nullable' => true,
                'comment'  => 'Paxful Track ID'
            ]
        );

        $installer->endSetup();
    }
}
