<?php

namespace Paxful\Payments\Controller\Payment;

use Magento\Framework\App\Action\Action;

class Index extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Checkout\Helper\Data
     */
    protected $checkoutHelper;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     * @var \Paxful\Payments\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var \Magento\Sales\Model\Service\InvoiceService
     */
    protected $invoiceService;

    /**
     * @var \Magento\Framework\DB\Transaction
     */
    protected $dbTransaction;

    /**
     * Index constructor.
     *
     * @param \Magento\Framework\App\Action\Context       $context
     * @param \Magento\Framework\View\Result\PageFactory  $resultPageFactory
     * @param \Magento\Checkout\Helper\Data               $checkoutHelper
     * @param \Magento\Sales\Model\OrderFactory           $orderFactory
     * @param \Paxful\Payments\Helper\Data               $helper
     * @param \Magento\Sales\Model\Service\InvoiceService $invoiceService
     * @param \Magento\Framework\DB\Transaction           $dbTransaction
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Checkout\Helper\Data $checkoutHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Paxful\Payments\Helper\Data $helper,
        \Magento\Sales\Model\Service\InvoiceService $invoiceService,
        \Magento\Framework\DB\Transaction $dbTransaction
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);

        $this->checkoutHelper = $checkoutHelper;
        $this->orderFactory = $orderFactory;

        $this->helper = $helper;
        $this->urlBuilder = $context->getUrl();
        $this->invoiceService = $invoiceService;
        $this->dbTransaction = $dbTransaction;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Exception
     */
    public function execute()
    {
        $session = $this->checkoutHelper->getCheckout();

        // Load Order
        $incrementId = $session->getLastRealOrderId();
        $order       = $this->orderFactory->create()->loadByIncrementId($incrementId);
        if (!$order->getId()) {
            $this->checkoutHelper->getCheckout()->restoreQuote();
            $this->messageManager->addError(__('No order for processing found'));
            $this->_redirect('checkout/cart');

            return;
        }

        /** @var \Magento\Payment\Model\Method\AbstractMethod $method */
        $method = $order->getPayment()->getMethodInstance();

        $currency = $order->getOrderCurrency()->getCurrencyCode();
        $amount = $order->getGrandTotal();

        // Create track ID
        $track_id = $order->getIncrementId() . '-' . uniqid();
        $order->setPaxfulTrackId($track_id);
        $order->save();

        $payload = [
            'merchant'   => $method->getConfigData('merchant_id'),
            'apikey'     => $method->getConfigData('api_key'),
            'nonce'      => time(),
            'track_id'   => $track_id,
            'amount'     => $amount,
            'user_email' => $order->getBillingAddress()->getEmail(),
        ];

        if (!empty($method->getConfigData('bitcoin_address')) ) {
            $payload['to'] = $method->getConfigData('bitcoin_address');
        }

        if ($currency === 'BTC') {
            $payload['amount'] = $amount;
        } else {
            $payload['fiat_amount']   = $amount;
            $payload['fiat_currency'] = $currency;
        }

        $url = $this->helper->getPaymentUrl($payload, $method->getConfigData('api_secret'));

        // Redirect to Paxful
        $resultRedirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($url);

        return $resultRedirect;
    }
}
