<?php

namespace Paxful\Payments\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Sales\Model\Order\Payment\Transaction;

/**
 * @SuppressWarnings(PHPMD.LongVariable)
 */
class Webhook extends AbstractHelper
{
    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    /**
     * @var \Magento\Framework\App\Response\Http
     */
    protected $response;

    /**
     * @var \Paxful\Payments\Logger\WebhooksLogger
     */
    protected $webhooksLogger;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $eventManager;

    /**
     * @var \Magento\Sales\Api\TransactionRepositoryInterface
     */
    protected $transactionRepository;

    /**
     * @var \Magento\Sales\Model\Order\Email\Sender\OrderSender
     */
    protected $orderSender;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Request\Http                 $request
     * @param \Magento\Framework\App\Response\Http                $response
     * @param \Paxful\Payments\Logger\WebhooksLogger              $webhooksLogger
     * @param \Psr\Log\LoggerInterface                            $logger
     * @param \Magento\Framework\Event\ManagerInterface           $eventManager
     * @param Data                                                $helper
     * @param \Magento\Sales\Model\OrderFactory                   $orderFactory
     * @param \Magento\Sales\Api\TransactionRepositoryInterface   $transactionRepository
     * @param \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender
     */
    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\App\Response\Http $response,
        \Paxful\Payments\Logger\WebhooksLogger $webhooksLogger,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Paxful\Payments\Helper\Data $helper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Sales\Api\TransactionRepositoryInterface $transactionRepository,
        \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender
    ) {
        $this->request = $request;
        $this->response = $response;
        $this->webhooksLogger = $webhooksLogger;
        $this->logger = $logger;
        $this->helper = $helper;
        $this->eventManager = $eventManager;
        $this->orderFactory = $orderFactory;
        $this->transactionRepository = $transactionRepository;
        $this->orderSender = $orderSender;
    }

    /**
     * Dispatch Event
     */
    public function dispatchEvent()
    {
        try {
            $payload = $this->request->getPostValue();
            $this->webhooksLogger->addInfo('WebHook', [$payload]);

            $track_id = $payload['track_id'];

            $order = $this->orderFactory->create()->loadByAttribute('paxful_track_id', $track_id);
            if (!$order->getId()) {
                throw new \Exception('Unable to find order by track id');
            }

            $this->webhooksLogger->addInfo('Order is found', [$order->getIncrementId(), $payload['status']]);

            switch ( $payload['status'] ) {
                case 'SUCCESSFUL':
                    // Payment is success
                    $message = __('Order has been paid.');

                    // Change order status
                    $orderState = \Magento\Sales\Model\Order::STATE_PROCESSING;
                    $orderStatus = $order->getConfig()->getStateDefaultStatus($orderState);
                    $order->setData('state', $orderState);
                    $order->setStatus($orderStatus);
                    $order->addStatusHistoryComment($message, $orderStatus);

                    // Check Transaction is already registered
                    $trans = $this->transactionRepository->getByTransactionId(
                        $track_id,
                        $order->getPayment()->getId(),
                        $order->getId()
                    );

                    // Register Transaction
                    if (!$trans) {
                        $order->getPayment()->setTransactionId($track_id);
                        $trans = $order->getPayment()->addTransaction(Transaction::TYPE_PAYMENT, null, true);
                        $trans->setIsClosed(0);
                        //$trans->setAdditionalInformation(Transaction::RAW_DETAILS, $transaction);
                        $trans->save();

                        // Set Last Transaction ID
                        $order->getPayment()->setLastTransId($track_id)->save();
                    }

                    // Create Invoice
                    if (!$order->hasInvoices()) {
                        $invoice = $this->helper->makeInvoice($order, [], false);
                        $invoice->setTransactionId($track_id);
                        $invoice->save();
                    }

                    $order->save();

                    // Send order notification
                    try {
                        $this->orderSender->send($order);
                    } catch (\Exception $e) {
                        $this->logger->critical($e);
                    }

                    $this->webhooksLogger->addInfo('Order has been paid');
                    break;
                case 'CANCELED':
                    $message = __('Order has been cancelled.');

                    // Cancel order
                    $order->cancel();
                    $order->addStatusHistoryComment($message);
                    $order->save();

                    $this->webhooksLogger->addInfo('Order has been cancelled');
                    break;
            }
        } catch (\Exception $e) {
            $this->webhooksLogger->addError($e->getMessage());
        }
    }
}
